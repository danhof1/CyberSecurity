
//import com.google.api.client.googleapis.auth.oauth2;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.FileContent;
import com.google.api.client.http.HttpRequestInitializer;
//import com.google.auth.http.HttpCredentialsAdapter;
//import com.google.auth.oauth2.GoogleCredentials;



import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;

/* class to demonstrate use of Drive files list API */
public class DriveQuickstart {
  /**
   * Application name.
   */
  private static final String APPLICATION_NAME = "RAT Trap";
  /**
   * Global instance of the JSON factory.
   */
  private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
  /**
   * Directory to store authorization tokens for this application.
   */
  private static final String TOKENS_DIRECTORY_PATH = "tokens";

  /**
   * Global instance of the scopes required by this quickstart.
   * If modifying these scopes, delete your previously saved tokens/ folder.
   */
  private static final List<String> SCOPES =
      Collections.singletonList(DriveScopes.DRIVE);
  private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

  /**
   * Creates an authorized Credential object.
   *
   * @param HTTP_TRANSPORT The network HTTP Transport.
   * @return An authorized Credential object.
   * @throws IOException If the credentials.json file cannot be found.
   */
  private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT)
      throws IOException {
    // Load client secrets.
    InputStream in = DriveQuickstart.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
    if (in == null) {
      throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
    }
    GoogleClientSecrets clientSecrets =
        GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

    // Build flow and trigger user authorization request.
    GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
        HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
        .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
        .setAccessType("offline")
        .build();
    LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
    Credential credential = new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
    //returns an authorized Credential object.
    return credential;
  }


  public static void main(String[] args) throws IOException, GeneralSecurityException {
    final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
    Drive service = new Drive.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
            .setApplicationName(APPLICATION_NAME)
            .build();

    // List files
    listFiles(service);

    // Upload a file
    uploadFile(service, "testing.txt", "text/plain");

    // Download a file
    downloadFile(service, "1Sz7vCCue4M105rsXW4KZ-VKbxRZqz-JO", "/Users/kevinrosa/Desktop/CSC AI CODE FIRST PROJECT.png");
  }

  //refactored method to listFiles
  private static void listFiles(Drive service) throws IOException {
    FileList result = service.files().list()
            .setPageSize(100)
            .setFields("nextPageToken, files(id, name)")
            .execute();
    List<File> files = result.getFiles();
    if (files == null || files.isEmpty()) {
        System.out.println("No files found.");
    } else {
        System.out.println("Files:");
        for (File file : files) {
            System.out.printf("%s (%s)\n", file.getName(), file.getId());
        }
    }
  }

  // Refactored method to upload a file
  private static void uploadFile(Drive service, String fileName, String fileMimetype) throws IOException {
    File fileMetadata = new File();
    fileMetadata.setName(fileName);
    fileMetadata.setMimeType(fileMimetype);

    java.io.File filePath = new java.io.File("/Users/kevinrosa/Desktop/hello.txt");
    FileContent mediaContent = new FileContent("text/plain", filePath);

    File file = service.files().create(fileMetadata, mediaContent)
            .setFields("id")
            .execute();

    System.out.println("Uploaded File ID: " + file.getId());
  }

  // Refactored method to download a file
  private static void downloadFile(Drive service, String fileId, String destinationFilePath) {
    try {
        OutputStream outputStream = new FileOutputStream(destinationFilePath);
        service.files().get(fileId).executeMediaAndDownloadTo(outputStream);
        System.out.println("File downloaded successfully to: " + destinationFilePath);
    } catch (IOException errorcode) {
        System.err.println("Error downloading the file: " + errorcode.getMessage());
        errorcode.printStackTrace();
    }
  }
}
// [END drive_quickstart]
