package Backend.MainThings;

import java.io.IOException;

public class ratBooter {
	public void bootRat() throws IOException, InterruptedException {
		actionBranch ab = new actionBranch();
		ab.actionMethod(13);
		ab.actionMethod(0);
	}
 
}
