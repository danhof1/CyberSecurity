# vault-hold-migration-api

This repository contains a code sample for Vault that generates a report on Mail
holds and copies them for Hangouts Chat.

Documentation is available on the
[Google Developers site](https://developers.google.com/vault/guides/chat).
